import { useState, useEffect } from 'react';

const sampleSweets = [
  { id: 1, name: 'Chocolate Cake', price: 15, quantity: 5 },
  { id: 2, name: 'Strawberry Donut', price: 5, quantity: 0 },
  { id: 3, name: 'Vanilla Ice Cream', price: 8, quantity: 10 },
];

export default function Dashboard() {
  const [sweets, setSweets] = useState(sampleSweets);
  const [search, setSearch] = useState('');

  // Filter sweets by search
  const filteredSweets = sweets.filter(s =>
    s.name.toLowerCase().includes(search.toLowerCase())
  );

  const handlePurchase = (id) => {
    setSweets(prev =>
      prev.map(s => {
        if (s.id === id && s.quantity > 0) {
          alert(`Purchased ${s.name}`);
          return { ...s, quantity: s.quantity - 1 };
        }
        return s;
      })
    );
  };

  return (
    <div style={{ maxWidth: 600, margin: 'auto', marginTop: 20 }}>
      <h1>Sweets Dashboard</h1>
      <input
        type="text"
        placeholder="Search sweets..."
        value={search}
        onChange={e => setSearch(e.target.value)}
        style={{ width: '100%', padding: 8, marginBottom: 20 }}
      />
      {filteredSweets.length === 0 && <p>No sweets found.</p>}
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {filteredSweets.map(sweet => (
          <li
            key={sweet.id}
            style={{
              border: '1px solid #ccc',
              padding: 10,
              marginBottom: 10,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <div>
              <strong>{sweet.name}</strong><br />
              Price: ${sweet.price} | Quantity: {sweet.quantity}
            </div>
            <button
              disabled={sweet.quantity === 0}
              onClick={() => handlePurchase(sweet.id)}
            >
              {sweet.quantity === 0 ? 'Out of Stock' : 'Purchase'}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
