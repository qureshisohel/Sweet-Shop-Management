import { useState } from 'react';

export default function AdminPanel() {
  const [sweets, setSweets] = useState([
    { id: 1, name: 'Chocolate Cake', price: 15, quantity: 5 },
    { id: 2, name: 'Strawberry Donut', price: 5, quantity: 2 },
  ]);
  const [form, setForm] = useState({ name: '', price: '', quantity: '', id: null });

  const handleSubmit = (e) => {
    e.preventDefault();
    const { name, price, quantity, id } = form;

    if (!name || !price || !quantity) {
      alert('Fill all fields');
      return;
    }

    if (id === null) {
      // Add new sweet
      const newSweet = {
        id: Date.now(),
        name,
        price: Number(price),
        quantity: Number(quantity),
      };
      setSweets([...sweets, newSweet]);
    } else {
      // Update existing sweet
      setSweets(sweets.map(s => s.id === id ? { ...s, name, price: Number(price), quantity: Number(quantity) } : s));
    }

    setForm({ name: '', price: '', quantity: '', id: null });
  };

  const handleEdit = (sweet) => {
    setForm(sweet);
  };

  const handleDelete = (id) => {
    if (confirm('Delete this sweet?')) {
      setSweets(sweets.filter(s => s.id !== id));
    }
  };

  return (
    <div style={{ maxWidth: 600, margin: 'auto', marginTop: 30 }}>
      <h2>Admin Panel - Manage Sweets</h2>

      <form onSubmit={handleSubmit} style={{ marginBottom: 30 }}>
        <input
          type="text"
          placeholder="Sweet name"
          value={form.name}
          onChange={e => setForm({ ...form, name: e.target.value })}
          required
          style={{ width: '100%', padding: 8, marginBottom: 10 }}
        />
        <input
          type="number"
          placeholder="Price"
          value={form.price}
          onChange={e => setForm({ ...form, price: e.target.value })}
          required
          style={{ width: '100%', padding: 8, marginBottom: 10 }}
        />
        <input
          type="number"
          placeholder="Quantity"
          value={form.quantity}
          onChange={e => setForm({ ...form, quantity: e.target.value })}
          required
          style={{ width: '100%', padding: 8, marginBottom: 10 }}
        />
        <button type="submit" style={{ padding: 10, width: '100%' }}>
          {form.id === null ? 'Add Sweet' : 'Update Sweet'}
        </button>
      </form>

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {sweets.map(s => (
          <li
            key={s.id}
            style={{
              border: '1px solid #ddd',
              padding: 10,
              marginBottom: 10,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <div>
              <strong>{s.name}</strong><br />
              Price: ${s.price} | Quantity: {s.quantity}
            </div>
            <div>
              <button onClick={() => handleEdit(s)} style={{ marginRight: 10 }}>Edit</button>
              <button onClick={() => handleDelete(s.id)}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
